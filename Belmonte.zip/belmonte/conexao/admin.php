<?php

if ($_SESSION['login']['cod_perfil'] != 1 && $_SESSION['login']['cod_perfil'] != 0){
    echo"<script language='javascript' type='text/javascript'>
        alert('Acesso restrito!');
        window.location.href='../index.php';</script>";
    die();
}