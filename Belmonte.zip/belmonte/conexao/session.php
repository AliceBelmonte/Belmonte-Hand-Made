<?php

session_start();

if (!isset($_SESSION['login'])) {
    echo"<script language='javascript' type='text/javascript'>
        alert('Faça o login!');
        window.location.href='../index.php';</script>";
    die();
}

$tempoLogado = time() - $_SESSION['login']['timestamp'];

$maxSessao = 60 * 60;

if ($tempoLogado > $maxSessao) {
    echo"<script language='javascript' type='text/javascript'>
        alert('Sua sessão expirou! Refaça o login!');
        window.location.href='../index.php';</script>";
    die();
}

$_SESSION['login']['timestamp'] = time();