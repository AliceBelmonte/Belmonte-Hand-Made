create database belmonte;

create table funcionarios(
    cod_func int auto_increment primary key,
    login_func varchar(100) not null unique,
    nome_func varchar(100) not null,
    senha_func varchar(32) not null,
    cod_perfil int not null,
    foreign key (cod_perfil) references perfil (cod_perfil)
)

create table clientes(
    cod_cliente int auto_increment primary key,
    cpf bigint unique not null,
    nome varchar(100) not null,
    email varchar(100) not null,
    telefone varchar(20),
    endereco varchar(100),
    estado varchar(2),
    cep varchar(9),
    cidade varchar(100)
)

create table produtos(
    cod_produto int auto_increment primary key,
    descricao_produto varchar(100) not null,
    quant_estoque int not null,
    valor_produto decimal(7,2),
    imagem varchar(100)
)

create table vendas(
    cod_venda int auto_increment primary key,
    nf bigint not null unique,
    valor_total decimal(7,2),
    cod_func int not null,
    cod_cliente  int not null,
    status bool,
    data date,
    foreign key (cod_func) references funcionarios (cod_func),
    foreign key (cod_cliente) references clientes (cod_cliente)
)

create table produtos_vendas(
    cod_produto int not null,
    cod_venda  int not null,
    quantidade int,
    valor_total decimal (7,2),
    valor_unit decimal (7,2),
    primary key (cod_produto,cod_venda),
    foreign key (cod_produto) references produtos (cod_produto),
    foreign key (cod_venda) references vendas (cod_venda)
)

create table perfil (
    cod_perfil  int not null primary key,
    nome_perfil varchar(15) not null
)

