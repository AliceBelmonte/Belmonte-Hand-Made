<?php

include_once "../conexao/session.php";

include_once "../conexao/conexao.php";

$executa = "SELECT * FROM produtos ORDER BY descricao_produto";

$query = $mysqli->query($executa);

while ($produto = $query->fetch_assoc()) {
?>
<option value="<?=$produto['cod_produto']?>">
    <?=$produto['cod_produto']?> - <?=$produto['descricao_produto']?>
</option>


<?php
}
