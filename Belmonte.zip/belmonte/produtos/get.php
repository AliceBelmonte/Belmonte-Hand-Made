<?php

include_once "../conexao/session.php";

include_once "../conexao/conexao.php";

$executa = "SELECT * FROM produtos WHERE cod_produto = ".$_GET['cod_produto'];

$query = $mysqli->query($executa);

$array = mysqli_fetch_array($query);

echo json_encode($array);