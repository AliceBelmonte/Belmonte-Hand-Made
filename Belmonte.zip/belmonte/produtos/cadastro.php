<?php
   include_once "../conexao/session.php";

   if (isset($_GET['cod_produto']) && $_GET['cod_produto'] != '') {
        include_once "../conexao/conexao.php";
        $executa = "SELECT * FROM produtos WHERE cod_produto = ".$_GET['cod_produto'];
        $query = $mysqli->query($executa);
        $produto = $query->fetch_assoc();
        $acao = 'Editar';
   } else {
        $acao = 'Incluir';
   }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <?php
        include_once '../header.php';
    ?>
    
    <title>Produtos</title>
</head>
<body>

<?php include_once '../menu.php'; ?>

    <div class="conteudo">
        <fieldset>

        <!-- Aqui começa o formulário de incluir dados  -->
            <form method="POST" action="grava.php" enctype="multipart/form-data">

            <font align ="center">
            <h1>
                <?=($acao=='Incluir')?'CADASTRO DE PRODUTOS':'EDITAR PRODUTO #'.$produto['cod_produto']?>
            </h1>
            </font>

            <table border="0"  style="border-spacing:15px";>
            <?php if ($acao == 'Editar') { ?>
                <input type="hidden" name="txtcodigo" value="<?=$produto['cod_produto']?>">
            <?php } ?>
            <tr>
                 <th>Nome do produto:</th>
                 <td><input type="text" name="txtnome" maxlength="55" size="80" placeholder="Ex: Dumbledore" value="<?=($acao=='Editar')?$produto['descricao_produto']:'' ?>"></td>
            </tr>
            <tr>
                <th>Valor: </th>
                <td><input type="text" id="valor" name="txtvalor" maxlength="55" size="80"  onkeypress='apenas_numero(event)' placeholder="R$ 999.99" value="<?=($acao=='Editar')?$produto['valor_produto']:''?>"></td>
            </tr>
                <th>Quantidade em estoque: </th>
                <td><input type="text" name="txtestoque" maxlength="55" size="80" placeholder="999"  onkeypress='apenas_numero(event)' value="<?=($acao=='Editar')?$produto['quant_estoque']:''?>"></td>
            </tr>
            <tr>
                <label for="txtimagem"><th>Imagem: </th></label>
                <td><input type="file" id="txtimagem" name="txtimagem" accept="image/*"></td>
            </tr>
            <?php
                if ($acao == 'Editar') {
                    ?>
                    <tr>
                        <label for="txtimagem"><th>Imagem atual: </th></label>
                        <td>
                            <img src="<?=$produto['imagem']?>" width="50px" />
                        </td>
                    </tr>
                    <?php
                }
            ?>
            </table>
            <br>
            <div  align ="center">
            <input type="submit" value="<?=$acao?>" name="enviar">
            <a href="index.php">
            <input type="button" value="voltar" name="voltar">
            </a>
            </div>   
            </form>
            
        <!-- Aqui termina o formulário de incluir dados, se necessário você pode substituí-lo pelo seu formulário -->
        </fieldset>
        
        <script>
            $(function() {
                $('#valor').maskMoney({thousands:''});
            })
        </script>
    </div>
</body>
</html>