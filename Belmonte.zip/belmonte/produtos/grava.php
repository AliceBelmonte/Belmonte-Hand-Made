<?php

include_once "../conexao/session.php";

// ligação entre o programa web e o banco de dados
include "../conexao/conexao.php";

if (isset($_POST['txtcodigo']) && $_POST['txtcodigo'] != '') {
    $cod = $_POST['txtcodigo'];
    $result = 'edita';
} else {
    $cod = null;
    $result = 'cadastra';
}

// capturando os dados preenchidos pelo usuário e armazenando na memória (variáveis)
$nome = $_POST["txtnome"];
$valor = $_POST["txtvalor"];
$estoque = $_POST["txtestoque"];

if (isset($_FILES['txtimagem']['name']) && $_FILES['txtimagem']['name'] != '') {
    $destino = '../imagem/produtos/'.time(). '_' . $_FILES['txtimagem']['name'];
    $arquivo_tmp = $_FILES['txtimagem']['tmp_name'];
    move_uploaded_file( $arquivo_tmp, $destino  );
} else {
    $destino = '';
}

// alunos é uma tabela no banco de dados

if (!is_null($cod)){
    $executa = "UPDATE produtos SET descricao_produto =  '$nome', valor_produto = $valor, quant_estoque = $estoque";
    if ($destino != '') {
        $executa .= ", imagem = '$destino'";
    }
    $executa .= " WHERE cod_produto = ".$_POST['txtcodigo'];
} else {
    $executa = "INSERT INTO produtos (descricao_produto , valor_produto , quant_estoque, imagem) VALUES ('$nome', $valor , $estoque, '$destino' )";
}

$query = $mysqli->query($executa);

if ($query) {
    $_SESSION['mensagem'] = '<div class="success"><b>Produto '.$result.'do com sucesso!</b></div>';
} else {
    $_SESSION['mensagem'] = '<div class="error"><b>Erro ao '.$result.'r Produto: '.$mysqli->error.'</b></div>';
}

echo"<script language='javascript' type='text/javascript'>
window.location.href='index.php';</script>";

