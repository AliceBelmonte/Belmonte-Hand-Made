<?php
    include_once "../conexao/session.php";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <?php include_once '../header.php'; ?>
    <title>Produtos</title>
</head>
<body>
    <?php include_once '../menu.php'; ?>
    <div class="conteudo">
        <fieldset>
        <h1>Consulta de Produtos: </h1><br><br>
        <table>
            <tr>                
                <th>Nome do Produto:</th>
               
                <td><input type="text" name="txtpesquisa" id="pesquisa_produto" maxlength="55" size="75"  style="margin-left:30%" placeholder="   Ex: Dumbledore"></td>
              
                <td> 
                    <a class="active" href="cadastro.php" style="margin-left:30%">
                    <input type="button" value="Cadastrar" name="cadastrar" href="cadastrar">
                </a></td>
            </tr>
        </table><br><br>
        <!--<div>
            <input type="button" value="Procurar" id="btn_pesquisa" name="Pesquisar"> 
            
                <a class="active" href="cadastro.php">
                <input type="button" value="Cadastrar" name="cadastrar" href="cadastrar" >
                </a>
            
        </div>-->

        </fieldset>
        <div class="mensagem">
            <?php
            if (isset($_SESSION['mensagem'])) {
                echo $_SESSION['mensagem'];
                unset($_SESSION['mensagem']);
            }
            ?>
        </div>
        <div class="lista_produtos"></div>
    </div>

    <script>
        $( document ).ready(function() {
            buscar(1);
        });  

        $("#pesquisa_produto").keyup(function() {
            buscar(1);
        });

        $('#btn_pesquisa').click(function(){
            // buscar();
        });

        $(".success").fadeOut(1000 * 5);
        $(".error").fadeOut(1000 * 30);

        function buscar(pagina){
            busca = $("#pesquisa_produto").val();
            $.get( "buscar.php?busca="+busca+"&pagina="+pagina, function( data ) {
                $( ".lista_produtos" ).html( data );
            });
        }
    </script>
</body>
</html>