<?php

include_once "../conexao/session.php";

    include_once "../conexao/conexao.php";
    
    $executa = "SELECT * FROM produtos";

    if (isset($_GET['busca']) && $_GET['busca'] != ''){
        $executa .= " WHERE descricao_produto LIKE '%".$_GET['busca']."%'";
    } 

    $executa .= " ORDER BY descricao_produto";

    $query = $mysqli->query($executa);

    $totalPorPagina = 7;

    if (isset($_GET['pagina']) && $_GET['pagina'] != '') {
        $pagina = (int) $_GET['pagina'] - 1;
        $executa .= " LIMIT {$totalPorPagina} OFFSET " . ($pagina*$totalPorPagina);
    }

    $query = $mysqli->query($executa);

?>
    <table id="tabelapesquisa">
        <tr>
            <th>Código</th>
            <th>Descrição</th>
            <th>Quantidade de Estoque</th>
            <th>Valor</th>
            <th>Imagem</th>
            <th>Editar</th>
            <th>Excluir</th>
        </tr>
<?php
    while ($produto = $query->fetch_assoc()) {
    ?>
        <tr>
            <td><?=$produto['cod_produto']?></td>
            <td><?=$produto['descricao_produto']?></td>
            <td><?=$produto['quant_estoque']?></td>
            <td>R$ <?=$produto['valor_produto']?></td>
            <td><img src="<?=$produto['imagem']?>" width="30px" class="zoom" /></td>
            <td>
                <a href='cadastro.php?cod_produto=<?=$produto['cod_produto']?>' title="Editar produto <?=$produto['descricao_produto']?>" class="pns">
                    <i class="fas fa-pencil-alt"></i>
                </a>
            </td>
            <td>
                <?php $descricao = $produto['descricao_produto']; ?>
                <a href='#' onclick="deleta(<?=$produto['cod_produto']?>, '<?=$descricao?>')" title="Deletar produto <?=$produto['descricao_produto']?>" class="dl">
                    <i class="fas fa-trash-alt"></i>
                </a>
            </td>
        </tr>
    <?php
    }    
?>

</table>
<center>
    <ul class="pagination">
        <li><a href="#" class='btn_pagina' page='1'>«</a></li>
        <?php
            $executa = "SELECT count(*) as total FROM produtos";
            if (isset($_GET['busca']) && $_GET['busca'] != ''){
                $executa .= " WHERE descricao_produto LIKE '%".$_GET['busca']."%' ";
            }
           
            $query = $mysqli->query($executa);
            $contadorDePaginas = mysqli_fetch_array($query);
            $totalPaginas = (int)ceil($contadorDePaginas['total'] / $totalPorPagina);
            
            for ($i = 1; $i <= $totalPaginas; $i++){
                ?>
                <li><a href="#" class='btn_pagina <?=(isset($_GET['pagina']) && $_GET['pagina']==$i)?'active':''?>' page='<?=$i?>'><?=$i?></a></li>
                <?php
            }
        ?>
        <li><a href="#" class='btn_pagina' page='<?=$totalPaginas?>'>»</a></li>
    </ul>
</center>

<script>
    function deleta(codigo_produto, descricao_produto) {
        if (confirm('Excluir o produto '+codigo_produto+' - ' + descricao_produto + '?')){
            window.location.href='deleta.php?cod_produto='+codigo_produto;
        }
    }

    $('.btn_pagina').click(function(){
        let pagina = $(this).attr('page');
        buscar(pagina);
    });
</script>