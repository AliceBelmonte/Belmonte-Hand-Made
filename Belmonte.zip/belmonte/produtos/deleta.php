<?php

include_once "../conexao/session.php";

if (!isset($_GET['cod_produto']) || $_GET['cod_produto'] == '') {
    echo "<script language='javascript' type='text/javascript'>
        alert('Informe o código do produto!');
        window.history.back();
        </script>";
    die();
}

$cod_produto = (int)$_GET['cod_produto'];

include "../conexao/conexao.php";
    
$executa = "DELETE FROM produtos WHERE cod_produto = ".$cod_produto;

$query = $mysqli->query($executa);

echo "<script language='javascript' type='text/javascript'>
        window.history.back();
        </script>";