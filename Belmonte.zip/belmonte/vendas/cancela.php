<?php

include_once "../conexao/session.php";

if (!isset($_GET['cod_venda']) || $_GET['cod_venda'] == '') {
    echo "<script language='javascript' type='text/javascript'>
        alert('Informe o código da Venda!');
        window.history.back();
        </script>";
    die();
}

$cod_venda = (int)$_GET['cod_venda'];

include "../conexao/conexao.php";
    
$executa = "UPDATE vendas SET status=0 WHERE cod_venda = ".$cod_venda;

$query = $mysqli->query($executa);

if ($query) {
    $executa = "SELECT * FROM produtos_vendas WHERE cod_venda = ".$cod_venda;
    $query = $mysqli->query($executa);

    while ($produto = $query->fetch_assoc()) {
        $executa = "UPDATE produtos SET quant_estoque = quant_estoque + ".$produto['quantidade']." WHERE cod_produto = ".$produto['cod_produto'];
        $mysqli->query($executa);
    }
}

echo "<script language='javascript' type='text/javascript'>
        window.history.back();
        </script>";