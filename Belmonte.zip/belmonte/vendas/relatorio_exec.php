<?php

    include_once "../conexao/session.php";

    include "../conexao/conexao.php";

    function converteData($data){
        $d = explode('/', $data);
        return $d[2].'-'.$d[1].'-'.$d[0];
    }

    $de = (isset($_GET['de']) && $_GET['de'] != '') ? converteData($_GET['de']) : false;
    $ate = (isset($_GET['ate']) && $_GET['ate'] != '') ? converteData($_GET['ate']) : false;
    $codCliente = (isset($_GET['cod_cliente']) && $_GET['cod_cliente'] != '') ? $_GET['cod_cliente'] : false;

    $getDe = (isset($_GET['de'])) ? $_GET['de'] : '';
    $getAte = (isset($_GET['ate'])) ? $_GET['ate'] : '';
    $getCodCliente = (isset($_GET['cod_cliente'])) ? $_GET['cod_cliente'] : '';

    $where = " WHERE v.status = 1";

    if ($de){
        $where .= " AND v.data >= '$de'";
    }

    if ($ate){
        $where .= " AND v.data <= '$ate'";
    }

    if ($codCliente) {
        $where .= " AND v.cod_cliente = $codCliente";
    }

    $executa = "SELECT v.*, c.nome FROM vendas v INNER JOIN clientes c ON c.cod_cliente = v.cod_cliente";
    $executa .= $where;
    $executa .= " ORDER BY v.data, v.cod_venda";

    $query = $mysqli->query($executa);

    if (isset($_GET['csv'])){
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=relatorio.csv');
        $saida = fopen('php://output', 'w');
        $header = [utf8_decode('Código'), 'Nota fiscal', 'Data', 'Cliente', 'Valor Total'];
        fputcsv($saida, $header, ';');
        while ($venda = $query->fetch_assoc()) {
            fputcsv($saida, [
                $venda['cod_venda'],
                $venda['nf'],
                $venda['data'],
                $venda['cod_cliente'].' - '.utf8_decode($venda['nome']),
                'R$ '.$venda['valor_total'],
            ], ';');
        }
        fclose($saida);
        die();
    }

    $sqlTotal = "SELECT SUM(valor_total) as total FROM vendas v $where";
    $queryTotal = $mysqli->query($sqlTotal);
    $total = mysqli_fetch_array($queryTotal);
    $valorTotal = $total['total'];
?>
   
    <div><a href="relatorio_exec.php?de=<?=$_GET['de']?>&ate=<?=$_GET['ate']?>&cod_cliente=<?=$_GET['cod_cliente']?>&csv=true" class="ets" style="text-decoration: none;">
        <input type="button" class="ets kr" name="Exportar" value="Exportar Arquivo">  
        </a>
        
            <td><b><input type="text" class="ctr readonly end" id="valor_total" name="txtvalor_total" readonly="true" size="35" value="Valor total :     R$  <?=$valorTotal?>"></b></td>
            
    </div>
    
    <table id="tabelapesquisa">
        <tr>
            <th>Código</th>
            <th>Nota Fiscal</th>
            <th>Data</th>
            <th>Cliente</th>
            <th>Valor Total</th>
            
        </tr>
<?php while ($venda = $query->fetch_assoc()) { ?>
        
   
    <tr class='consulta_venda' cod_venda="<?=$venda['cod_venda']?>">
        
        <td><?=$venda['cod_venda']?></td>
        <td><?=$venda['nf']?></td>
        <td>
            <?php
                $data = new DateTime($venda['data']);
                echo $data->format('d/m/Y');
            ?>    
        </td>
        <td><?=$venda['cod_cliente']?> - <?=$venda['nome']?></td>
        <td> R$ <?=$venda['valor_total']?></td>
        
    </tr>
        
        
    <?php
    }    
?>

</table>

<script>
      $(".consulta_venda").click(function(){
        let cod_venda = $(this).attr('cod_venda');
        window.location.href = 'consulta.php?cod_venda='+cod_venda+'&de=<?=$getDe?>&ate=<?=$getAte?>&cod_cliente=<?=$getCodCliente?>';
    });

</script>