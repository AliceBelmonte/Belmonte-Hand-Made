<?php

include_once "../conexao/session.php";

include_once "../conexao/conexao.php";

$executa = "SELECT nf FROM vendas order by nf desc limit 1";

$query = $mysqli->query($executa);

$array = mysqli_fetch_array($query);

$nfAtual = (isset($array['nf'])) ? $array['nf'] : 0;

echo 1 + $nfAtual;