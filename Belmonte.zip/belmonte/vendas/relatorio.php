<?php include_once "../conexao/session.php";?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <?php include_once '../header.php'; ?>
    <title>Vendas</title>
</head>
<body>
    <?php include_once '../menu.php'; ?>
    
        <div class="conteudo">
        <fieldset>
        <h1>Relatorio de Vendas : </h1><br><br>
            <div><th>Inicio  :  </th>
            <td><input type="text" id="de"  required   class='date' maxlength="55" size="10" placeholder="  Data Inicial"style="margin-right:5%" <?=(isset($_GET['de']))?"value='".$_GET['de']."'":''?>>

            <th>Final :  </th>
            <td><input type="text" id="ate" required  class='date' maxlength="55" size="10" placeholder="  Data Final"style="margin-right:3%" <?=(isset($_GET['ate']))?"value='".$_GET['ate']."'":''?>>
            <th>Cliente: </th>
            <select class="combo_cliente" id='cliente' required name="txtcod_cliente">
                <option value=''>Todos clientes</option>
                <?php 
                include_once '../cliente/combo.php';
                ?>
            </select>
            
             <br><br><br>
             
            <input type="button" id='gerar' value="Gerar Relatório" name="Buscar" style="margin-left:30%">
            
            <a href="index.php">
                <input type="button" value="Voltar" name="voltar" style="margin-left:1%">
            </a>
           </div><br>
        </fieldset>
        <div class="mensagem">
            <?php
            if (isset($_SESSION['mensagem'])) {
                echo $_SESSION['mensagem'];
                unset($_SESSION['mensagem']);
            }

            ?>
        </div>
        <div class="lista_vendas"></div>
        </div>
       
        <script>
             
            $(document).ready(function(){
                <?php 
                if (isset($_GET['cod_cliente'])){
                    echo "buscar();";
                }
                ?>

                $('.date').mask('00/00/0000');
                $('.date').datepicker({
                    dateFormat: 'dd/mm/yy',
                    dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],
                    dayNamesMin: ['D','S','T','Q','Q','S','S','D'],
                    dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb','Dom'],
                    monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
                    monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
                });
            });

            $('#gerar').click(function(){
                buscar();
            });

            $('.combo_cliente').select2();

            function buscar(){
                de = $("#de").val();
                ate = $("#ate").val();
                cliente = $("#cliente option:selected").val();
                $.get( "relatorio_exec.php?de="+de+"&ate="+ate+"&cod_cliente="+cliente, function( data ) {
                    $(".lista_vendas").html( data );
                });
            }
                 
        </script>