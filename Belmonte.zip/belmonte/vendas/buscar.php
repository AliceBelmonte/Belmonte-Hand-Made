<?php
    include_once "../conexao/session.php";

    include "../conexao/conexao.php";
    
    $executa = "SELECT v.*, c.nome FROM vendas v INNER JOIN clientes c ON c.cod_cliente = v.cod_cliente";

    if (isset($_GET['busca']) && $_GET['busca'] != ''){
        $executa .= " WHERE v.cod_cliente LIKE '%".$_GET['busca']."%' ";
        $executa .= "or c.nome LIKE '%".$_GET['busca']."%' ";
        $executa .= "or v.nf LIKE '%".$_GET['busca']."%' ";
    } 

    $executa .= " ORDER BY cod_venda DESC";

    $totalPorPagina = 7;

    if (isset($_GET['pagina']) && $_GET['pagina'] != '') {
        $pagina = (int) $_GET['pagina'] - 1;
        $executa .= " LIMIT {$totalPorPagina} OFFSET " . ($pagina*$totalPorPagina);
    }

    $query = $mysqli->query($executa);
?>
    <table id="tabelapesquisa">
        <tr>
            <th>Código</th>
            <th>Nota Fiscal</th>
            <th>Data</th>
            <th>Cliente</th>
            <th>Valor Total</th>
            
        </tr>
<?php while ($venda = $query->fetch_assoc()) { ?>
        
        <tr class='consulta_venda' cod_venda="<?=$venda['cod_venda']?>">
        
            <td>
                <div class="<?=($venda['status'])?'':'red'?>">
                    <?=$venda['cod_venda']?>
                    <?=($venda['status'])?'':'<div class="small">Cancelado</div>'?>
                </div>
            </td>
            <td><?=$venda['nf']?></td>
            <td>
                <?php
                    $data = new DateTime($venda['data']);
                    echo $data->format('d/m/Y');
                ?>    
            </td>
            <td><?=$venda['cod_cliente']?> - <?=$venda['nome']?></td>
            <td> R$ <?=$venda['valor_total']?></td>
            
        </tr>
        
    <?php
    }    
?>

</table>

<center>
    <ul class="pagination">
        <li><a href="#" class='btn_pagina' page='1'>«</a></li>
        <?php
            $executa = "SELECT count(*) as total FROM vendas";
            if (isset($_GET['busca']) && $_GET['busca'] != ''){
                $executa .= " v INNER JOIN clientes c on c.cod_cliente = v.cod_cliente";
                $executa .= " WHERE v.cod_cliente LIKE '%".$_GET['busca']."%' ";
                $executa .= "or c.nome LIKE '%".$_GET['busca']."%' ";
                $executa .= "or v.nf LIKE '%".$_GET['busca']."%' ";
            }
            $query = $mysqli->query($executa);
            $contadorDePaginas = mysqli_fetch_array($query);
            $totalPaginas = (int)ceil($contadorDePaginas['total'] / $totalPorPagina);
            
            for ($i = 1; $i <= $totalPaginas; $i++){
                ?>
                <li><a href="#" class='btn_pagina <?=(isset($_GET['pagina']) && $_GET['pagina']==$i)?'active':''?>' page='<?=$i?>'><?=$i?></a></li>
                <?php
            }
        ?>
        <li><a href="#" class='btn_pagina' page='<?=$totalPaginas?>'>»</a></li>
    </ul>
</center>
 
<script>
    $(".consulta_venda").click(function(){
        let cod_venda = $(this).attr('cod_venda');
        window.location.href = 'consulta.php?cod_venda='+cod_venda;
    });

    $('.btn_pagina').click(function(){
        let pagina = $(this).attr('page');
        buscar(pagina);
    });
</script>