<?php
    include_once "../conexao/session.php";

    include_once "../conexao/conexao.php";

    $executa = "SELECT v.*, c.nome FROM vendas v INNER JOIN clientes c ON c.cod_cliente = v.cod_cliente WHERE v.cod_venda = " .$_GET['cod_venda'];
    $query = $mysqli->query($executa);
    $venda = mysqli_fetch_array($query);

    $executa = "SELECT pv.*, p.descricao_produto , p.imagem FROM produtos_vendas pv INNER JOIN produtos p ON p.cod_produto = pv.cod_produto WHERE pv.cod_venda = ".$_GET['cod_venda']." order by p.descricao_produto";
    $query = $mysqli->query($executa);
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <?php include_once '../header.php'; ?>
        <title>Vendas</title>
    </head>
    <body>
        <?php include_once '../menu.php'; ?>
            <div class="conteudo">
            <fieldset>
            <font align ="center">
            <h1>VENDA N° <?=$_GET['cod_venda']?></h1>
            <?php if (!$venda['status']){ ?>
            <div class="red">CANCELADA</div>
            <?php } ?>
            </font>

            <table width="100%" id="tabela_produtos">
                    <tr rowspan="5"></tr>
                    <tr>
                        <th>Nota Fiscal: </th>
                        <th>Cliente: </th>
                        <th>Valor Total: </th>
                    </tr>

                    <tr>
                        <td><?=$venda['nf'] ?></td>
                        <td>
                            <a href="../cliente/cadastro.php?cod_cliente=<?=$venda['cod_cliente']?>&cod_venda=<?=$venda['cod_venda']?>">
                                <?=$venda['cod_cliente'] ?> - <?=$venda['nome'] ?>
                            </a>
                        </td>
                        <td>R$ <?=$venda['valor_total'] ?></td>
                    </tr>
                                
                </table>
                <table width="100%" id="tabela_produtos">
                    <tr rowspan="5"></tr>
                    <tr>
                        <th>Produtos: </th>
                        <th>Imagem: </th>
                        <th>Valor unitário: </th>
                        <th>Quantidade: </th>
                        <th>Valor Total: </th>
                    </tr>
                    <?php
                        while ($produto = $query->fetch_assoc()) {
                    ?>
                        <tr>
                        <td><?=$produto['cod_produto']?> - <?=$produto['descricao_produto']?></td>
                        <td><img src="<?=$produto['imagem']?>" width="30px" class="zoom" /></td>
                        <td><?=$produto['valor_unit']?></td>
                        <td><?=$produto['quantidade']?></td>
                        <td><?=$produto['valor_total']?></td>
                        </tr>
                    <?php
                    }
                    ?>
                
                </table></br>
                <center>
                    <?php
                    if (isset($_GET['de']) || isset($_GET['ate']) || isset($_GET['cod_cliente'])){
                        $href = "relatorio.php?";
                        if (isset($_GET['de'])) {
                            $href .= "&de=".$_GET['de'];
                        }
                        if (isset($_GET['ate'])) {
                            $href .= "&ate=".$_GET['ate'];
                        }
                        if (isset($_GET['cod_cliente'])) {
                            $href .= "&cod_cliente=".$_GET['cod_cliente'];
                        }
                    } else {
                        $href = "index.php";
                    }
                    ?>
                    <a href="<?=$href?>" style="text-decoration: none;">
                        <input type="button" value="voltar" name="voltar" />
                    </a>
                        <?php if ($venda['status']){ ?>
                            <a href='#' onclick="deleta( <?=$venda['cod_venda']?>)"
                                title="Cancelar Venda <?=$venda['cod_venda']?>">
                                <input type="button" class="reds" value="Cancelar a Venda" name="Cancelar">
                            </a>
                        <?php } ?>   
                </center>   
        </fieldset>
        <script>
    function deleta(cod_venda) {

        if (confirm('Cancelar a Venda N° '+cod_venda+' ?')){
            window.location.href='cancela.php?cod_venda='+cod_venda;
        }
    }
        </script>
    </body>
</html>
