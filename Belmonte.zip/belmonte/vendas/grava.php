<?php

include_once "../conexao/session.php";

// ligação entre o programa web e o banco de dados
include "../conexao/conexao.php";

// capturando os dados preenchidos pelo usuário e armazenando na memória (variáveis)
$nf = $_POST["txtnf"];
$cod_cliente = $_POST["txtcod_cliente"];
$valor_total = removeRs($_POST["txtvalor_total"]);
$cod_func = $_SESSION['login']['cod_func'];
$data = date("Y-m-d");

if (!isset($_POST['id_produto']) || $_POST['id_produto'] == ''){
    $_SESSION['mensagem'] = '<div class="error"><b>Cadastre ao menos um produto.</b></div>';
} else {

    // alunos é uma tabela no banco de dados
    $executa = "INSERT INTO vendas (nf , cod_cliente , valor_total, cod_func, data, status) 
    VALUES ( $nf , $cod_cliente , $valor_total , $cod_func , '$data', true)";

    $query = $mysqli->query($executa);

    if ($query) {
        $executa = "SELECT max(cod_venda) as cod_venda FROM vendas";
        $query = $mysqli->query($executa);
        $array = mysqli_fetch_array($query);
        $cod_venda = $array['cod_venda'];

        $cod_produto = $_POST['id_produto'];
        $valor_unit = $_POST['valor_unit'];
        $quantidade = $_POST['quantidade'];
        $total = $_POST['valor_total_produto'];
        
        for ($i = 0; $i < count($cod_produto); $i++) {
            $executa = "INSERT INTO produtos_vendas (cod_produto, cod_venda, quantidade, valor_total, valor_unit)
            VALUES (".$cod_produto[$i].", $cod_venda, ".$quantidade[$i].", ".$total[$i].", ".$valor_unit[$i].")";
        
            $query = $mysqli->query($executa);

            if ($query) {
                $executa = "UPDATE produtos SET quant_estoque = quant_estoque - ".$quantidade[$i]." WHERE cod_produto = ".$cod_produto[$i];
                $query = $mysqli->query($executa);
            }
        }
    }

    if ($query) {
        $_SESSION['mensagem'] = '<div class="success"><b>Venda cadastrada com sucesso!</b></div>';
    } else {
        $_SESSION['mensagem'] = '<div class="error"><b>Erro ao cadastrar a Venda: '.$mysqli->error.'</b></div>';
    }
}

echo"<script language='javascript' type='text/javascript'>
      window.location.href='cadastro.php';</script>";

function removeRs($valor)
{
    $dado = explode(" ", $valor);
    return $dado[2];
}