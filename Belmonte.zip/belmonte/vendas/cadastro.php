<?php
    include_once "../conexao/session.php";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <?php include_once '../header.php'; ?>
    <title>Vendas</title>
    
</head>
<body>
    <?php include_once '../menu.php'; ?>

    <div class="conteudo">
        <fieldset>

        <!-- Aqui começa o formulário de incluir dados  -->
            <form method="POST" action="grava.php">

            <font align ="center">
            <h1 id="titulo">NOVA VENDA</h1>
            </font>
            
            <table border="0">
             
           
            <tr>
                <th>Cliente: </th>
                <td>
                <select class="combo_cliente" required name="txtcod_cliente">
                    <option></option>
                    <?php 
                    include_once '../cliente/combo.php';
                    ?>
                </select>
                
                <input type="hidden" id="txtnf" name="txtnf">
                </td><br>
                               
               <th>Valor total: </th>
                <td><input type="text"  class="ctr readonly"  id="valor_total" name="txtvalor_total" readonly="true"  value=" R$ 00.00"></td>
            </tr>   
            <tr colspan="2">
            
                <table width="100%" id="tabela_produtos">
                    <tr rowspan="5">
                        <hr />
                    </tr>
                    <tr>
                        <th>Produto: </th>
                        <th>Valor unitário: </th>
                        <th>Estoque disponível: </th>
                        <th>Quantidade: </th>
                        <th>Valor Total: </th>
                        <th></th>
                        
                    </tr>
                
                    <tr>
                        <td>
                            <select class="combo_produto" id="combo_produto">
                                <option></option>
                                <?php 
                                include_once '../produtos/combo.php';
                                ?>
                            </select>
                        </td>
                        
                        <td>
                            <input type="text" class="ctr readonly" readonly="true" id="valor_unit" placeholder=" Valor unitário">
                        </td>
                        
                        <td>
                            <input type="text" class="ctr readonly" readonly="true" id="estoque" placeholder=" Quantidade disponível">
                        </td>

                        <td>
                            <input type="text" class="ctr"  id="qtde_produto" requered  placeholder=" Quantidade" onkeypress='apenas_numero(event)'/>
                        </td>

                        <td>
                            <input type="text" class="ctr readonly"  readonly="true" id="total_produto" placeholder=" Valor Total do Produto" />
                        </td>
                        <td>
                            <a href="#" id="add_produto" class="green">
                                <i class="fas fa-plus-circle"></i>
                            </a>
                        </td>
                    </tr>
                
                </table>
            </tr>                                     
            </table>
            <br>
            <div  align ="center">
            <input type="submit" value="Incluir" name="enviar">
            <a href="index.php">
            <input type="button" value="voltar" name="voltar">
            </a>
            </div>   
           
            </form>

        <!-- Aqui termina o formulário de incluir dados, se necessário você pode substituí-lo pelo seu formulário -->
        </fieldset>
        <div class="mensagem">
            <?php
            if (isset($_SESSION['mensagem'])) {
                echo $_SESSION['mensagem'];
                unset($_SESSION['mensagem']);
            }

            ?>
        </div>
        <script>
            $(".success").fadeOut(1000 * 5);
            $(".error").fadeOut(1000 * 30);

            $(document).ready(function() {
                $('.combo_cliente').select2({
                    placeholder: "Selecione o cliente"
                });
                $('.combo_produto').select2({
                    placeholder: "Selecione o produto"
                });

                $.get( "get_nf.php", function( data ) {
                    $( "#txtnf" ).val( data );
                    $( "#titulo" ).html( 'NOVA VENDA - N°'+ data );
                });
            });

            $("#combo_produto").change(function() {
                let campo = 'valor_produto';

                if ($("#combo_produto").val() != '') {
                    $.getJSON( "../produtos/get.php?cod_produto="+$("#combo_produto").val(), function( data ) {
                        $("#valor_unit").val(data.valor_produto);
                        let estoque = parseInt(data.quant_estoque);

                        let total_quantidade_produto = 0;

                        $(".estoque_"+data.cod_produto).each(function(){
                            total_quantidade_produto += parseInt($(this).val());
                        });
                        $("#estoque").val(estoque - total_quantidade_produto);
                    });
                }
                $("#total_produto").val('');
                $("#qtde_produto").val('');

            });

            $("#qtde_produto").keyup(function() {
                $("#total_produto").val(
                    parseFloat($("#valor_unit").val() * $("#qtde_produto").val()).toFixed(2)
                );
            });

            $("#add_produto").click(function(){
                add_produto();
            });

            function desativa_produto_combo(id_produto)
            {
                $('#combo_produto option[value="'+id_produto+'"]').attr("disabled", true);
            }

            function reativa_produto_combo(id_produto)
            {
                $('#combo_produto option[value="'+id_produto+'"]').removeAttr("disabled");
            }

            function add_produto(){
                let id_produto = $("#combo_produto").val();
                let produto = $("#combo_produto option:selected").text();
                let valor_unit = $("#valor_unit").val();
                let estoque = $("#estoque").val();
                let quantidade = $("#qtde_produto").val();
                let valor_total = $("#total_produto").val();

                if (parseInt(quantidade) > parseInt(estoque)){
                    alert('Quantidade indisponível. Quantidade em estoque: '+estoque);
                    return;
                }

                if (parseInt(quantidade) < 1){
                    // alert('Quantidade indisponível. Quantidade em estoque: '+estoque);
                    return;
                }

                if (id_produto != '' &&
                    produto != '' &&
                    valor_unit != '' &&
                    quantidade != '' &&
                    valor_total != '') {
                    $("#tabela_produtos tr:last").after(
                        "<tr id='produto_"+id_produto+"'>"
                        + "<td>"+produto+" <input type='hidden' name='id_produto[]' value='"+id_produto+"' /></td>"
                        + "<td>"+valor_unit+" <input type='hidden' name='valor_unit[]' value='"+valor_unit+"' /></td>"
                        + "<td colspan='2'><input type='hidden' class='estoque_"+id_produto+"' value='"+quantidade+"'>"+quantidade+" <input type='hidden' name='quantidade[]' value='"+quantidade+"' /></td>"
                        + "<td class='valor_total_produto'>"+parseFloat(valor_total).toFixed(2)+" <input type='hidden' name='valor_total_produto[]' value='"+parseFloat(valor_total).toFixed(2)+"' /></td>"
                        + "<td><a href='#' onclick='remover_produto("+id_produto+");' class='red'><i class='fas fa-minus-circle'></i></a></td>"
                        + "</tr>"
                    );
                    limpa();
                    soma();
                    desativa_produto_combo(id_produto);
                } else {
                    alert('preencha todos os campos');
                }
            }

            function remover_produto(id)
            {
                $('#produto_'+id).remove();
                soma();
                reativa_produto_combo(id);
            }

            function limpa(){
                $("#combo_produto").val('').change();
                $("#valor_unit").val('');
                $("#total_produto").val('');
                $("#qtde_produto").val('');
                $("#estoque").val('');
            }

            function soma(){
                let total = 0;
                $(".valor_total_produto").each(function(){
                    total += parseFloat($(this).text());
                });
                $('#valor_total').val(" R$ "+total.toFixed(2));
            }
        </script>
    </div>
</body>