<?php
    include_once "../conexao/session.php";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <?php include_once '../header.php'; ?>
    <title>Vendas</title>
</head>
<body>
    <?php include_once '../menu.php'; ?>
    <div class="conteudo">
        <fieldset>
        
        <h1>Consulta de vendas: </h1><br>
        
        <table>
            <tr>
                <th>Buscar Venda  :  </th>
                <td><input type="text" name="txtpesquisa" maxlength="55" size="75" id="pesquisa_vendas" placeholder="   Digite o Nome do Cliente ou o N° da Nota Fiscal">  
            <a class="active" href="cadastro.php" style="text-decoration: none;">
                <input type="button" value="Cadastrar" name="cadastrar" href="cadastrar" style="margin-left:5%">
            </a>
            <a class="active" href="relatorio.php">
                <input type="button" value="Relatorio de Vendas" name="relatorio" href="relatorio" style="margin-left:2%">
            </a>
        </td>
            </tr>
        
        </table><br><br>
        
        </fieldset>
        
        <div class="lista_vendas"></div>

    </div>
    

    <script>
        $( document ).ready(function() {
            buscar(1);
        });  

        $("#pesquisa_vendas").keyup(function() {
            buscar(1);
        });

        $('#btn_pesquisa').click(function(){
            // buscar();
        });

        function buscar(pagina){
            busca = $("#pesquisa_vendas").val();
            $.get( "buscar.php?busca="+busca+"&pagina="+pagina, function( data ) {
                $( ".lista_vendas" ).html( data );
            });
        }
        
    </script>
    </div>
</body>
</html>