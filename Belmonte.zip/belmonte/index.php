<?php
session_start();

if (isset($_GET['logar']) && $_GET['logar'] == 'true') {

  if (!isset($_POST['login']) || !isset($_POST['senha'])) {
    echo"<script language='javascript' type='text/javascript'>
      window.location.href='index.php';</script>";
    die();
  }

  $login = $_POST['login'];
  $senha = MD5($_POST['senha']);

  $connect = mysqli_connect('localhost','root','', 'belmonte');
  $query_select = "SELECT f.*, p.nome_perfil FROM funcionarios f INNER JOIN perfil p on f.cod_perfil = p.cod_perfil WHERE f.login_func = '$login' and f.senha_func = '$senha'";
  $select = mysqli_query($connect, $query_select);
  $array = mysqli_fetch_assoc($select);

  if (is_null($array)) {
    $_SESSION['mensagem_erro'] = 'Usuário e/ou senha inválidos';
    echo"<script language='javascript' type='text/javascript'>
      window.location.href='index.php';</script>";
    die();
  }

  unset($_SESSION['mensagem_erro']);
  $_SESSION['login'] = $array;
  // Não salvar a senha na sessão
  unset($_SESSION['login']['senha_func']);
  $_SESSION['login']['timestamp'] = time();

  echo"<script language='javascript' type='text/javascript'>
      window.location.href='cliente/';</script>";
    die();

} else {
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Login</title>
      <link href="css/login.css" rel="stylesheet">
      <link rel="shortcut icon" href="imagem/favicon.ico" type="image/x-icon">
      <link rel="icon" href="imagem/favicon.ico" type="image/x-icon">
  </head>
  <body>
          <center>
              <img class='logotipo' src="imagem/loga.jpg" />
          </center>
      <?php
      if (isset($_SESSION['mensagem_erro'])) { ?>
        <center>
          <div style="background-color:red;">
            <?=$_SESSION['mensagem_erro']?>
          </div>
        </center>
      <?php 
      unset($_SESSION['mensagem_erro']);
      } 
    ?>
      <form action="index.php?logar=true" method="POST">
              <div class="f1"> 
                  <fieldset>
                      <legend><h3>Faça Login Para Iniciar Uma Nova Sessão</h3></legend></br>
                      <h3>Login:</h3>
                      <input type="text" name="login" id="" required='true' placeholder="Insira seu E-mail"></br>
                      <h3>Senha:</h3>
                      <input type="password" name="senha" id="" required='true' placeholder="insira sua Senha"></br></br> 
                      <a class="active">                   
                      <button type="submit" value="entrar" name="entrar"class="btn2">Entrar</button></br>
                      </a>
                  </fieldset>
              </div>
      </form>
  </body>
</html>
<?php
}