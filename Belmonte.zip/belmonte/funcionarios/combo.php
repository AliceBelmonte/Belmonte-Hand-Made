<?php

include_once "../conexao/session.php";
include_once "../conexao/admin.php";

include_once "../conexao/conexao.php";

$executa = "SELECT * FROM perfil WHERE cod_perfil > 0 ORDER BY cod_perfil";

$query = $mysqli->query($executa);

while ($perfil = $query->fetch_assoc()) {
?>
<option value="<?=$perfil['cod_perfil']?>" <?=($acao == 'Editar' && isset($funcionarios['cod_perfil']) && $funcionarios['cod_perfil'] == $perfil['cod_perfil'])?'selected':''?>>
    <?=$perfil['cod_perfil']?> - <?=$perfil['nome_perfil']?>
</option>


<?php
}
