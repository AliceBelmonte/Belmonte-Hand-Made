<?php
	
	include_once "../conexao/session.php";
	
	if (isset($_POST['senhaatual']) && $_POST['senhaatual'] != '') {

        $senhaAtual = md5($_POST['senhaatual']);

        include_once "../conexao/conexao.php";
        
        $executa = "SELECT senha_func FROM funcionarios WHERE cod_func = ".$_SESSION['login']['cod_func'];
        $query = $mysqli->query($executa);
        $array = mysqli_fetch_array($query);

        if ($senhaAtual != $array['senha_func']){
            $_SESSION['mensagem'] = '<div class="error"><b>Senha atual inválida!</b></div>';
        } elseif ($_POST['novasenha'] != $_POST['senhaconfirma']) {
            $_SESSION['mensagem'] = '<div class="error"><b>Nova senha não confere com a confirmação!</b></div>';
        } else {
            $senha = md5($_POST['novasenha']);
            $executa = "UPDATE funcionarios SET senha_func = '$senha' WHERE cod_func = ".$_SESSION['login']['cod_func'];
            $query = $mysqli->query($executa);
            $_SESSION['mensagem'] = '<div class="success"><b>Senha atualizada com sucesso!</b></div>';
        } 
   } 
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>

	<?php
	include_once '../header.php';
	?>
	<title>Senha</title>
	
</head>

<body>
	<?php
	include_once '../menu.php';
	?>
	<div class="conteudo">
		<fieldset>

		<!-- Aqui começa o formulário de incluir dados  -->
		    <form method="POST" id="altsenha">
                
			<font align ="center">
			<h1>
				Alterar Minha Senha			
			</h1>
			</font>

			<table border="0" style="border-spacing:15px";>
				
			<tr>
			     <th>Senha atual :</th>
				 <td><input type="password" name="senhaatual" maxlength="55" size="44" required placeholder=" Digite sua senha atual"></td>
			</tr>
			<tr>
				<th>Nova Senha : </th>
				<td><input type="password" name="novasenha" id="nova" maxlength="55" size="44" required  placeholder=" Digite a nova senha"></td>
			</tr>
            <tr>
                <th>Confirmar Nova Senha : </th>
                <td><input type="password" name="senhaconfirma" id="confirm" maxlength="55" size="44" required  placeholder=" Confirme a nova senha "></td>
                
            </tr>               
                
            </table>
			<br>
			<div  align ="center">
			<input type="submit" value="Alterar" name="enviar">
		    </div>  
		    </form>
	
		<!-- Aqui termina o formulário de incluir dados, se necessário você pode substituí-lo pelo seu formulário -->
		</fieldset>
        <?php
            if (isset($_SESSION['mensagem'])) {
                echo "<br><center>".$_SESSION['mensagem']."</center>";
                unset($_SESSION['mensagem']);
            }

            ?>
		<script>
            $(".success").fadeOut(1000 * 5);
            $(".error").fadeOut(1000 * 15);

            $("#altsenha").submit(function(e){
                let confirm = $("#confirm").val();
                let nova = $("#nova").val();

                if (confirm != nova){
                    alert('Nova senha não bate com a confirmação');
                    e.preventDefault();
                }
            });
		</script>
	</div>
</body>
</html>