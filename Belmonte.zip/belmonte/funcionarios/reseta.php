<?php

include_once "../conexao/session.php";
include_once "../conexao/admin.php";

if (!isset($_GET['cod_func']) || $_GET['cod_func'] == '')  {
    echo "<script language='javascript' type='text/javascript'>
    alert('Informe o codigo do Funcionario!');
    window.history.back();
    </script>";
    die();
}

$cod_func = (int)$_GET['cod_func'];
$senha_func = md5("123456");
include "../conexao/conexao.php";
    
$executa = "UPDATE funcionarios set senha_func = '$senha_func' WHERE cod_func = ".$cod_func;

$query = $mysqli->query($executa);

if ($query) {
    $_SESSION['mensagem'] = '<div class="success"><b>Senha resetada com sucesso!</b></div>';
} else {
    $_SESSION['mensagem'] = '<div class="error"><b>Erro ao resetar a senha '.$mysqli->error.'</b></div>';
}

echo "<script language='javascript' type='text/javascript'>
        window.history.back();
        </script>";
