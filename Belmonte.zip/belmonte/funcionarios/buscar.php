<?php

include_once "../conexao/session.php";
include_once "../conexao/admin.php";

    include_once "../conexao/conexao.php";
    
    $executa = "SELECT f.* , p.nome_perfil FROM funcionarios f INNER JOIN perfil p on f.cod_perfil = p.cod_perfil";
    $executa .= " WHERE cod_func > 0";
    if (isset($_GET['busca']) && $_GET['busca'] != ''){
        $executa .= " AND f.nome_func LIKE '%".$_GET['busca']."%'";
        
        
    } 

    $executa .= " ORDER BY f.cod_func";

    $query = $mysqli->query($executa);

?>
    <table id="tabelapesquisa">
        <tr>
            <th>Codigo</th>
            <th>Nome</th>
            <th>Login</th>
            <th>Perfil</th>
            <th>Editar</th>
            <th>resetar Senha</th>
        </tr>
<?php
    while ($funcionarios = $query->fetch_assoc()) {
    ?>
        <tr>
             <td><?=$funcionarios['cod_func']?></td>
            <td><?=$funcionarios['nome_func']?></td>
            <td><?=$funcionarios['login_func']?></td>
            <td><?=$funcionarios['nome_perfil']?></td>
            <td>
                <a href='cadastro.php?cod_func=<?=$funcionarios['cod_func']?>' title="Editar Funcionario <?=$funcionarios['nome_func']?>" class="pns">
                    <i class="fas fa-pencil-alt"></i>
                </a>
            </td>
            <td>
            <?php $descricao = $funcionarios['nome_func']; ?>
                <a href='#' onclick="reseta(<?=$funcionarios['cod_func']?>, '<?=$descricao?>')"
                 title="Resetar Funcionario <?=$funcionarios['nome_func']?>" class="dl">
                 <i class="fas fa-wrench"></i>
                </a>
            </td>
        </tr>
    <?php
     }    
    ?>

</table>
<script>
    function reseta(cod_func, nome_func) {

        if (confirm('Resetar a senha do funcionario '+cod_func+' - ' + nome_func + '?')){
            window.location.href='reseta.php?cod_func='+cod_func;
        }
    }
</script>

