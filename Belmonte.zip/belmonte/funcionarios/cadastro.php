<?php
	
	include_once "../conexao/session.php";
	include_once "../conexao/admin.php";

	if (isset($_GET['cod_func']) && $_GET['cod_func'] != '') {
        include_once "../conexao/conexao.php";
        $executa = "SELECT * FROM funcionarios WHERE cod_func = ".$_GET['cod_func'];
        $query = $mysqli->query($executa);
        $funcionarios = $query->fetch_assoc();
        $acao = 'Editar';
   } else {
        $acao = 'Incluir';
   }
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>

	<?php
	include_once '../header.php';
	?>
	<title>Funcionarios</title>
	
</head>

<body>
	<?php
	include_once '../menu.php';
	?>
	<div class="conteudo">
		<fieldset>

		<!-- Aqui começa o formulário de incluir dados  -->
		    <form method="POST" action="grava.php">

			<font align ="center">
			<h1>
				
			<?=($acao=='Incluir')?'CADASTRO DE FUNCIONARIOS':'EDITAR FUNCIONARIO #'.$funcionarios['cod_func']?>
			
			</h1>
			</font>

			<table border="0" style="border-spacing:15px";>
				
			<tr>
			<?php if ($acao == 'Editar') { ?>
                <input type="hidden" name="cod_func" value="<?=$funcionarios['cod_func']?>">
            <?php } ?>
				 <th>Nome :</th>
				 <td><input type="text" name="nome_func" maxlength="55" size="80" placeholder=" Ex: João Paulo da Silva" value="<?=($acao=='Editar')?$funcionarios['nome_func']:''?>"></td>
			</tr>
			<tr>
				<th>Login : </th>
				<td><input type="email" name="login_func" maxlength="55" size="44" placeholder=" exemplo@email.com" value="<?=($acao=='Editar')?$funcionarios['login_func']:''?>"></td>
			</tr>
            <tr>
                <th>Perfil : </th>
                <td>
                    <select class="combo_perfil" id="combo_perfil" name="cod_perfil">
                        <option></option>
                        <?php 
                        include_once '../funcionarios/combo.php';
                        ?>
                    </select>
                </td>

            </tr>
                
                
            </table>
			<br>
			<div  align ="center">
			<input type="submit" value="<?=$acao?>" name="enviar">
		    <a href="<?=(isset($_GET['cod_perfil'])&&$_GET['cod_perfil']!='')?'../funcionarios/cadastro.php?cod_perfil='.$_GET['cod_perfil']:'index.php'?>">
            	<input type="button" value="voltar" name="voltar">
            </a>
		    </div>   
		    </form>
	
		<!-- Aqui termina o formulário de incluir dados, se necessário você pode substituí-lo pelo seu formulário -->
		</fieldset>
		
		<script>
             $(document).ready(function() {
                $('.combo_perfil').select2({
                    placeholder: "Selecione o Perfil"
                });
            });
		</script>
	</div>
</body>
</html>