<?php
    include_once "../conexao/session.php";
    include_once "../conexao/admin.php";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <?php include_once '../header.php'; ?>
    <title>Funcionarios</title>
</head>
<body>
    <?php include_once '../menu.php'; ?>
    <div class="conteudo">
    
        <fieldset>
        <h1>Consulta de Funcionarios: </h1><br><br>
        <table>
            <tr>
                <th>Funcionario : </th>
                <td><input type="text" name="txtpesquisa" id="txtpesquisa" maxlength="55" size="75" placeholder="   Digite o Nome do funcionario">           
            <a class="active" href="cadastro.php" style="margin-left:30%">
                <input type="button" value="Cadastrar" name="cadastrar" href="cadastrar">
            </a>
        </td>
            
            
            </tr>
            
            <!-- <tr>
                <th>CPF: </th>
                <td><input type="text" name="txtcpf" maxlength="15" size="15" placeholder="XXX.XXX.XXX-XX"></td>
            </tr> -->
        </table><br><br>
        
        </fieldset>
        <div class="mensagem">
            <?php
            if (isset($_SESSION['mensagem'])) {
                echo $_SESSION['mensagem'];
                unset($_SESSION['mensagem']);
            }

            ?>
        </div>
          
           
             
        <div class="lista_funcionario"></div>
    </div>
    </div>

    <script>
        $(".success").fadeOut(1000 * 5);
        $(".error").fadeOut(1000 * 30); 

        $( document ).ready(function() {
            buscar();
        });  

        $("#txtpesquisa").keyup(function() {
            buscar();
        });

        $('#btn_pesquisa').click(function(){
            // buscar();
        });

        function buscar(){
            busca = $("#txtpesquisa").val();
            $.get( "buscar.php?busca="+busca, function( data ) {
                $( ".lista_funcionario" ).html( data );
            });
        }
        
    </script>
</body>
</html>
