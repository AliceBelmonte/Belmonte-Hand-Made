<?php

include_once "../conexao/session.php";
include_once "../conexao/admin.php";

// ligação entre o programa web e o banco de dados
include "../conexao/conexao.php";

//  verificar se edição ou cadastro
if (isset($_POST['cod_func']) && $_POST['cod_func'] != '') {
    $cod = $_POST['cod_func'];
    $result = 'edita';
} else {
    $cod = null;
    $result = 'cadastra';
}

// capturando os dados preenchidos pelo usuário e armazenando na memória (variáveis)
$nome = $_POST["nome_func"];
$login = $_POST["login_func"];
$senha = md5("123456");
$perfil = $_POST['cod_perfil'];


if (!is_null($cod)){
    $executa = "UPDATE funcionarios set nome_func = '$nome',login_func = '$login' ,senha_func = '$senha',cod_perfil = $perfil WHERE cod_func = ".$cod;
} else {
    $executa = "INSERT INTO funcionarios (nome_func, login_func, senha_func, cod_perfil) 
    VALUES ('$nome', '$login', '$senha', $perfil)";
}

$query = $mysqli->query($executa);


if ($query) {
    $_SESSION['mensagem'] = '<div class="success"><b>Funcionario '.$result.'do com sucesso!</b></div>';
} else {
    $_SESSION['mensagem'] = '<div class="error"><b>Erro ao '.$result.'r funcionario: '.$mysqli->error.'</b></div>';
}

echo"<script language='javascript' type='text/javascript'>
window.location.href='index.php';</script>";
?>