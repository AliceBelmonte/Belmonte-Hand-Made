<!-- <meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="../css/estilos.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://kit.fontawesome.com/35bc34f1b9.js" crossorigin="anonymous"></script> -->

<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="../css/estilos.css">
<script src="../script.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Crimson+Text&family=Inconsolata:wght@500&family=Open+Sans&family=Open+Sans+Condensed:wght@300&family=Staatliches&display=swap" rel="stylesheet">
<meta name="theme-color" content="#ffffff">

<script src="https://kit.fontawesome.com/35bc34f1b9.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script src="../jquery.maskMoney.js"></script>

<link rel="stylesheet" href="http://code.jquery.com/ui/1.9.0/themes/base/jquery-ui.css" />
<script src="http://code.jquery.com/ui/1.9.0/jquery-ui.js"></script>

<link rel="shortcut icon" href="../imagem/favicon.ico" type="image/x-icon">
<link rel="icon" href="../imagem/favicon.ico" type="image/x-icon">