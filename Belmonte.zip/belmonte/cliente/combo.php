<?php

include_once "../conexao/session.php";

include_once "../conexao/conexao.php";

$executa = "SELECT * FROM clientes ORDER BY nome";

$query = $mysqli->query($executa);

while ($cliente = $query->fetch_assoc()) {
    ?>
    <option value="<?=$cliente['cod_cliente']?>" <?=(isset($_GET['cod_cliente']) && $_GET['cod_cliente'] == $cliente['cod_cliente'])?' selected':''?>>
        <?=$cliente['cpf']?> - <?=$cliente['nome']?>
    </option>


    <?php
}
