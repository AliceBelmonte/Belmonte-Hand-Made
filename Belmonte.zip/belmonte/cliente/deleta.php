<?php

include_once "../conexao/session.php";

if (!isset($_GET['cod_cliente']) || $_GET['cod_cliente'] == '') {
    echo "<script language='javascript' type='text/javascript'>
        alert('Informe o código do Cliente!');
        window.history.back();
        </script>";
    die();
}

$cod_cliente = (int)$_GET['cod_cliente'];

include "../conexao/conexao.php";
    
$executa = "DELETE FROM clientes WHERE cod_cliente = ".$cod_cliente;

$query = $mysqli->query($executa);

echo "<script language='javascript' type='text/javascript'>
        window.history.back();
        </script>";