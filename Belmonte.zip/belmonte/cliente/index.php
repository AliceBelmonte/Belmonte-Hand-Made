<?php
    include_once "../conexao/session.php";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <?php include_once '../header.php'; ?>
    <title>Clientes</title>
</head>
<body>
    <?php include_once '../menu.php'; ?>
    <div class="conteudo">
    
    
        <fieldset>
        <h1>Consulta de Cliente: </h1><br><br>
        <table>
            <tr>
                <th>Cliente: </th>
                <td><input type="text" name="txtpesquisa" id="txtpesquisa" maxlength="55" size="75" placeholder="   Digite o Nome, E-mail ou CPF">           
            <a class="active" href="cadastro.php" style="margin-left:30%">
                <input type="button" value="Cadastrar" name="cadastrar" href="cadastrar">
            </a>
        </td>
            
            
            </tr>
            
            <!-- <tr>
                <th>CPF: </th>
                <td><input type="text" name="txtcpf" maxlength="15" size="15" placeholder="XXX.XXX.XXX-XX"></td>
            </tr> -->
        </table><br><br>
        
        </fieldset>
        <div class="mensagem">
            <?php
            if (isset($_SESSION['mensagem'])) {
                echo $_SESSION['mensagem'];
                unset($_SESSION['mensagem']);
            }
            ?>
    </div>
       
        <div class="lista_cliente"></div>
    </div>
    
   </div>
    
    
    <script>

         $(".success").fadeOut(1000 * 5);
	     $(".error").fadeOut(1000 * 30);

        $( document ).ready(function() {
            buscar(1);
        });  

        $("#txtpesquisa").keyup(function() {
            buscar(1);
        });

        $('#btn_pesquisa').click(function(){
            // buscar();
        });

        function buscar(pagina){
            busca = $("#txtpesquisa").val();
            $.get( "buscar.php?busca="+busca+"&pagina="+pagina, function( data ) {
                $( ".lista_cliente" ).html( data );
            });
        }
    </script>
</body>
</html>
