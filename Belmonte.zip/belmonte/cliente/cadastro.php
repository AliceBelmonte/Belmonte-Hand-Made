<?php
	
	include_once "../conexao/session.php";

	if (isset($_GET['cod_cliente']) && $_GET['cod_cliente'] != '') {
        include_once "../conexao/conexao.php";
        $executa = "SELECT * FROM clientes WHERE cod_cliente = ".$_GET['cod_cliente'];
        $query = $mysqli->query($executa);
        $cliente = $query->fetch_assoc();
        $acao = 'Editar';
   } else {
        $acao = 'Incluir';
   }
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>

	<?php
	include_once '../header.php';
	?>
	<title>Clientes</title>
	
</head>

<body>
	<?php
	include_once '../menu.php';
	?>
	<div class="conteudo">
		<fieldset>

		<!-- Aqui começa o formulário de incluir dados  -->
		    <form method="POST" action="grava.php">

			<font align ="center">
			<h1>
				
			<?=($acao=='Incluir')?'CADASTRO DE CLIENTES':'EDITAR CLIENTE #'.$cliente['cod_cliente']?>
			
			</h1>
			</font>

			<table border="0" style="border-spacing:15px";>
				<?php if ($acao == 'Editar') { ?>
					<input type="hidden" name="txtcodigo" value="<?=$cliente['cod_cliente']?>">
				<?php } ?>
			<tr>
				 <th>Nome:</th>
				 <td><input type="text" name="txtnome" maxlength="55" size="80" required placeholder=" Ex: João Paulo da Silva" value="<?=($acao=='Editar')?$cliente['nome']:''?>"></td>
			</tr>
			<tr>
				<th>E-mail: </th>
				<td><input type="email" name="txtemail" maxlength="55" size="44" required placeholder=" exemplo@email.com" value="<?=($acao=='Editar')?$cliente['email']:''?>"></td>
			</tr>
				<th>Celular: </th>
				<td><input type="text" name="txtcelular" class="telefone" maxlength="55" size="80" required placeholder=" (11) 9XXXX-XXXX" value="<?=($acao=='Editar')?$cliente['telefone']:''?>"></td>
			</tr>
			<tr>
				<th>Endereço: </th>
				<td><input type="text" name="txtendereco" maxlength="55" size="80" required placeholder=" Ex: Rua São Mauricio, 1754" value="<?=($acao=='Editar')?$cliente['endereco']:''?>"></td>
			</tr>	
			<tr>
				<th>Cidade: </th>
				<td><input type="text" name="txtcidade" maxlength="55" size="80" required placeholder=" Ex: Guarulhos" value="<?=($acao=='Editar')?$cliente['cidade']:''?>"></td>
			</tr>
			<tr>
				<label><th>Estado: </th></label>
				<td><select id="estado" required name="estado">
					<option value="">Selecione o Estado</option>
				    <option value="AC" <?=($acao=='Editar'&&$cliente['estado']=='AC')?'selected':''?>>Acre</option>
				    <option value="AL" <?=($acao=='Editar'&&$cliente['estado']=='AL')?'selected':''?>>Alagoas</option>
				    <option value="AP" <?=($acao=='Editar'&&$cliente['estado']=='AP')?'selected':''?>>Amapá</option>
				    <option value="AM" <?=($acao=='Editar'&&$cliente['estado']=='AM')?'selected':''?>>Amazonas</option>
				    <option value="BA" <?=($acao=='Editar'&&$cliente['estado']=='BA')?'selected':''?>>Bahia</option>
				    <option value="CE" <?=($acao=='Editar'&&$cliente['estado']=='CE')?'selected':''?>>Ceará</option>
				    <option value="DF" <?=($acao=='Editar'&&$cliente['estado']=='DF')?'selected':''?>>Distrito Federal</option>
				    <option value="ES" <?=($acao=='Editar'&&$cliente['estado']=='ES')?'selected':''?>>Espírito Santo</option>
				    <option value="GO" <?=($acao=='Editar'&&$cliente['estado']=='GO')?'selected':''?>>Goiás</option>
				    <option value="MA" <?=($acao=='Editar'&&$cliente['estado']=='MA')?'selected':''?>>Maranhão</option>
				    <option value="MT" <?=($acao=='Editar'&&$cliente['estado']=='MT')?'selected':''?>>Mato Grosso</option>
				    <option value="MS" <?=($acao=='Editar'&&$cliente['estado']=='MS')?'selected':''?>>Mato Grosso do Sul</option>
				    <option value="MG" <?=($acao=='Editar'&&$cliente['estado']=='MG')?'selected':''?>>Minas Gerais</option>
				    <option value="PA" <?=($acao=='Editar'&&$cliente['estado']=='PA')?'selected':''?>>Pará</option>
				    <option value="PB" <?=($acao=='Editar'&&$cliente['estado']=='PB')?'selected':''?>>Paraíba</option>
				    <option value="PR" <?=($acao=='Editar'&&$cliente['estado']=='PR')?'selected':''?>>Paraná</option>
				    <option value="PE" <?=($acao=='Editar'&&$cliente['estado']=='PE')?'selected':''?>>Pernambuco</option>
				    <option value="PI" <?=($acao=='Editar'&&$cliente['estado']=='PI')?'selected':''?>>Piauí</option>
				    <option value="RJ" <?=($acao=='Editar'&&$cliente['estado']=='RJ')?'selected':''?>>Rio de Janeiro</option>
				    <option value="RN" <?=($acao=='Editar'&&$cliente['estado']=='RN')?'selected':''?>>Rio Grande do Norte</option>
				    <option value="RS" <?=($acao=='Editar'&&$cliente['estado']=='RS')?'selected':''?>>Rio Grande do Sul</option>
				    <option value="RO" <?=($acao=='Editar'&&$cliente['estado']=='RO')?'selected':''?>>Rondônia</option>
				    <option value="RR" <?=($acao=='Editar'&&$cliente['estado']=='RR')?'selected':''?>>Roraima</option>
				    <option value="SC" <?=($acao=='Editar'&&$cliente['estado']=='SC')?'selected':''?>>Santa Catarina</option>
				    <option value="SP" <?=($acao=='Editar'&&$cliente['estado']=='SP')?'selected':''?>>São Paulo</option>
				    <option value="SE" <?=($acao=='Editar'&&$cliente['estado']=='SE')?'selected':''?>>Sergipe</option>
				    <option value="TO" <?=($acao=='Editar'&&$cliente['estado']=='TO')?'selected':''?>>Tocantins</option>
				    <option value="EX" <?=($acao=='Editar'&&$cliente['estado']=='EX')?'selected':''?>>Estrangeiro</option>
				</select></td>
			</tr>
			<tr>
				<th>CPF: </th>
				<td><input type="text" name="txtcpf" class='cpf' maxlength="15" required size="16" placeholder=" XXX.XXX.XXX-XX"  onkeypress='apenas_numero(event)' value="<?=($acao=='Editar')?$cliente['cpf']:''?>"></td>
			</tr>
			<tr>
				<th>CEP: </th>
				<td><input type="text" name="txtcep" class='cep' required maxlength="10" size="16" placeholder=" XXXXX-XXX" value="<?=($acao=='Editar')?$cliente['cep']:''?>"></td>
	        </tr>
		
						
		    </table>
			<br>
			<div  align ="center"> 
			<input type="submit" value="<?=$acao?>" name="enviar">
		    <a href="<?=(isset($_GET['cod_venda'])&&$_GET['cod_venda']!='')?'../vendas/consulta.php?cod_venda='.$_GET['cod_venda']:'index.php'?>">
            	<input type="button" value="voltar" name="voltar">
            </a>
		    </div>   
		    </form>
	
		<!-- Aqui termina o formulário de incluir dados, se necessário você pode substituí-lo pelo seu formulário -->
		</fieldset>
		<div class="mensagem">
            <?php
            if (isset($_SESSION['mensagem'])) {
                echo $_SESSION['mensagem'];
                unset($_SESSION['mensagem']);
            }

            ?>
        </div>
		<script>
            $(".success").fadeOut(1000 * 5);
			$(".error").fadeOut(1000 * 30);
			
			$(document).ready(function(){
				$('.cep').mask('00000-000');
				$('.cpf').mask('000.000.000-00');
				$('.telefone').mask('(00) 90000-0000');
				
			});
			$('.telefone').keyup(function(event) {
   if($(this).val().length == 15){ // Celular com 9 dígitos + 2 dígitos DDD e 4 da máscara
      $('.telefone').mask('(00) 90000-0000');
   } else {
      $('.telefone').mask('(00) 9000-00000');
   }
	});
	</script>
	</div>
</body>
</html>