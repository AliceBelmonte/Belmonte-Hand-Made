<?php

include_once "../conexao/session.php";

// ligação entre o programa web e o banco de dados
include "../conexao/conexao.php";

if (isset($_POST['txtcodigo']) && $_POST['txtcodigo'] != '') {
    $cod = $_POST['txtcodigo'];
    $result = 'edita';
} else {
    $cod = null;
    $result = 'cadastra';
}

// capturando os dados preenchidos pelo usuário e armazenando na memória (variáveis)
$nome = $_POST["txtnome"];
$email = $_POST["txtemail"];
$telefone = $_POST["txtcelular"];
$endereco = $_POST['txtendereco'];
$cidade = $_POST['txtcidade'];
$estado = $_POST['estado'];
$cpf = $_POST['txtcpf'];
$cep = $_POST['txtcep'];


if (!is_null($cod)){
    $executa = "UPDATE clientes set nome = '$nome',cpf = '$cpf' ,email = '$email',telefone = '$telefone',
    endereco = '$endereco',estado = '$estado',cep = '$cep',cidade = '$cidade' WHERE cod_cliente = ".$cod;
} else {
    $executa = "INSERT INTO clientes (nome, cpf, email, telefone, endereco, estado, cep, cidade) 
    VALUES ('$nome', '$cpf', '$email', '$telefone', '$endereco', '$estado', '$cep', '$cidade')";
}
$query = $mysqli->query($executa);


if ($query) {
    $_SESSION['mensagem'] = '<div class="success"><b>Cliente '.$result.'do com sucesso!</b></div>';
} else {
    $_SESSION['mensagem'] = '<div class="error"><b>Erro ao '.$result.'r cliente: '.$mysqli->error.'</b></div>';
}

if (!is_null($cod)){
    echo"<script language='javascript' type='text/javascript'>
        window.location.href='cadastro.php?cod_cliente=".$cod."';</script>";
} else {
    echo"<script language='javascript' type='text/javascript'>
        window.location.href='index.php';</script>";
}
?>