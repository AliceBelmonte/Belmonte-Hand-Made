<?php

include_once "../conexao/session.php";

    include_once "../conexao/conexao.php";
    
    $executa = "SELECT * FROM clientes";

    if (isset($_GET['busca']) && $_GET['busca'] != ''){
        $executa .= " WHERE nome LIKE '%".$_GET['busca']."%'";
        
    }
        $query = $mysqli->query($executa);
     

    $executa .= " ORDER BY cod_cliente";

    $totalPorPagina = 7;

    if (isset($_GET['pagina']) && $_GET['pagina'] != '') {
        $pagina = (int) $_GET['pagina'] - 1;
        $executa .= " LIMIT {$totalPorPagina} OFFSET " . ($pagina*$totalPorPagina);
    }

    $query = $mysqli->query($executa);

?>
    <table id="tabelapesquisa">
        <tr>
            <th>Código</th>
            <th>Nome</th>
            <th>E-mail</th>
            <th>Celular</th>
            <th>CPF</th>
            <th>Editar</th>
            <th>Excluir</th>
            
        </tr>
<?php
    while ($cliente = $query->fetch_assoc()) {
    ?>
        <tr>
            <td><?=$cliente['cod_cliente']?></td>
            <td><?=$cliente['nome']?></td>
            <td><?=$cliente['email']?></td>
            <td><?=$cliente['telefone']?></td>
            <td><?=$cliente['cpf']?></td>
            
            
            <td>
                <a href='cadastro.php?cod_cliente=<?=$cliente['cod_cliente']?>' title="Editar cliente <?=$cliente['nome']?>" class="pns">
                    <i class="fas fa-pencil-alt"></i>
                </a>
            </td>
            <td>
                <?php $descricao = $cliente['nome']; ?>
                <a href='#' onclick="deleta(<?=$cliente['cod_cliente']?>, '<?=$descricao?>')" title="Deletar Cliente <?=$cliente['nome']?>" class="dl">
                    <i class="fas fa-trash-alt"></i>
                </a>
            </td>
        </tr>
    <?php
    }    
?>

</table>
<center>
    <ul class="pagination">
        <li><a href="#" class='btn_pagina' page='1'>«</a></li>
        <?php
            $executa = "SELECT count(*) as total FROM clientes";
            if (isset($_GET['busca']) && $_GET['busca'] != ''){
                $executa .= " WHERE nome LIKE '%".$_GET['busca']."%'";
            }
            $query = $mysqli->query($executa);
            $contadorDePaginas = mysqli_fetch_array($query);
            $totalPaginas = (int)ceil($contadorDePaginas['total'] / $totalPorPagina);
            
            for ($i = 1; $i <= $totalPaginas; $i++){
                ?>
                <li><a href="#" class='btn_pagina <?=(isset($_GET['pagina']) && $_GET['pagina']==$i)?'active':''?>' page='<?=$i?>'><?=$i?></a></li>
                <?php
            }
        ?>
        <li><a href="#" class='btn_pagina' page='<?=$totalPaginas?>'>»</a></li>
    </ul>
</center>

<script>
    function deleta(cod_cliente, nome) {

        if (confirm('Excluir o Cliente '+cod_cliente+' - ' + nome + '?')){
            window.location.href='deleta.php?cod_cliente='+cod_cliente;
        }}

        $('.btn_pagina').click(function(){
            let pagina = $(this).attr('page');
            buscar(pagina);
        });
</script>