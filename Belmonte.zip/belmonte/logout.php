<?php

session_start();

unset($_SESSION['login']);

echo"<script language='javascript' type='text/javascript'>
      window.location.href='index.php';</script>";
    die();