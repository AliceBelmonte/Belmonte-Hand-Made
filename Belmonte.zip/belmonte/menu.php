<div class="sidebar">
    <a class="active" href="../cliente/"><i class="fas fa-address-book"></i> Clientes</a>
    <a class="active" href="../produtos/"><i class="fas fa-box-open"></i> Produtos</a>
    <a class="active" href="../vendas/"><i class="fas fa-dollar-sign"></i> Vendas</a>
    <?php if ($_SESSION['login']['cod_perfil'] == 1 || $_SESSION['login']['cod_perfil'] == 0){ ?>
        <a class="active" href="../funcionarios/"><i class="fas fa-user-tie"></i> Funcionarios</a>
    <?php } ?>
    <a href="../funcionarios/alterarsenha.php"><i class="fas fa-key"></i> Alterar Minha Senha</a>
    <a class="active" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a>
    <div style="margin-top:100px;padding:15px;color:#778899;font-family:'Open Sans Condensed',sans-serif">
    <i class="fas fa-user"></i><b>  Usuário logado : </b><br><br><b><?=$_SESSION['login']['nome_func']?></b> <br>
    <?=$_SESSION['login']['login_func']?><br><?=$_SESSION['login']['nome_perfil']?></div>
</div>